library('emepTools')

setwd('/home/neumannd/TMP/emep_tools/package/emepPackagesTesting/emep_data')


cat('\n~~~~~~~~~~~~\n READ FILES INTO R \n~~~~~~~~~~~~\n')
cat('SHOULD WORK: read file into R with read.emepFile \n')
myData1 = read.emepFile('DE/DE0044R.20110101000000.20110704000000.online_IC..pm10.5mo.1h.DE08L_Metrohm_1.DE08L_IFT_ION_CHROMATOGRAPHY..nas')
cat('SHOULD WORK: read file into R with read.emepFile \n')
myData2 = read.emepFile('DK/DK0031R.20110101070000.20121001000000.filter_3pack.calcium.aerosol.1y.1d.DK01L_FP6N_31.DK01L_IC..nas')
myData3 = read.emepFile('/media/neumannd/work_mn/64_EMEP/ebas_2015/NO/NO0002R.20130102070000.20140317000000.kfg.organic_carbon..52w.1w.NO01L_kfg_no01.NO01L_Thermo_Optical-Sunset_Lab_EUSAAR-2..nas')
myData4 = read.emepFile('PL/PL0002R.20110101060000.20120620000000.filter_2pack..aerosol.1y.1d.PL01L_f2p_02...nas')


cat('\n~~~~~~~~~~~~\n GENERATE EMPTY EMEP DATA \n~~~~~~~~~~~~\n')
cat('\nSHOULD WORK: generate empty EMEP data with getEmptyEmepData \n')
myDataEmpty = getEmptyEmepData()


cat('\n~~~~~~~~~~~~\n CONVERT DATA FORMAT FOR CTMEVAL \n~~~~~~~~~~~~\n')
cat("\nSHOULD WORK: convert EMEP data into format for the 'ctmeval' package with convert2ctmeval.emepdata \n")
myDataCtmeval = convert2ctmeval.emepdata(myData1, calc_mean = FALSE)
cat("\nAchtung: Der Output ist noch kein echtes observationts Objekt. \n")


